local selling = false
local npcPed = nil
local npcActive = false
local playerLevel = 1

local function debugPrint(msg)
    print("[rd_drugdealer DEBUG]: " .. msg)
end

RegisterNetEvent('rd_drugdealer:notifyToggle', function(state)
    selling = state

    if not selling then
        if DoesEntityExist(npcPed) then
            ClearPedTasks(npcPed)
            DeleteEntity(npcPed)
            npcPed = nil
        end

        if DoesEntityExist(PlayerPedId()) then
            ClearPedTasks(PlayerPedId())
        end

        npcActive = false
    end

    if selling then
        lib.notify({
            title = Config.NotificationTitles.script,
            description = Config.NotificationTitles.startSuccess,
            type = Config.NotificationTypes.start
        })
    else
        lib.notify({
            title = Config.NotificationTitles.script,
            description = Config.NotificationTitles.stopSuccess,
            type = Config.NotificationTypes.stop
        })
    end
end)

local function GetRandomEntry(tbl)
    return tbl[math.random(1, #tbl)]
end

local function SpawnBuyer()
    if npcActive then return end

    local unlockedDrugs = {}
    for _, drug in ipairs(Config.SellableDrugs) do
        if playerLevel >= drug.requiredLevel then
            table.insert(unlockedDrugs, drug)
        end
    end

    if #unlockedDrugs == 0 then return end

    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local spawnRadius = Config.NPC.spawnRadius

    local pedModel = GetHashKey(GetRandomEntry(Config.NPC.models))
    RequestModel(pedModel)
    while not HasModelLoaded(pedModel) do
        Citizen.Wait(10)
    end

    local angle = math.random() * 2.0 * math.pi
    local spawnX = playerCoords.x + spawnRadius * math.cos(angle)
    local spawnY = playerCoords.y + spawnRadius * math.sin(angle)
    local _, groundZ = GetGroundZFor_3dCoord(spawnX, spawnY, playerCoords.z + 50.0, false)
    local spawnPos = vector3(spawnX, spawnY, groundZ)

    npcPed = CreatePed(4, pedModel, spawnPos.x, spawnPos.y, spawnPos.z, 0.0, true, false)

    if not DoesEntityExist(npcPed) then
        debugPrint("Failed to create NPC ped!")
        return
    end

    debugPrint("NPC spawned!")
    SetPedCanRagdoll(npcPed, false)
    SetPedConfigFlag(npcPed, 185, true)
    SetPedConfigFlag(npcPed, 208, true)
    TaskSetBlockingOfNonTemporaryEvents(npcPed, true)
    SetEntityAsMissionEntity(npcPed, true, true)
    SetPedKeepTask(npcPed, true)

    npcActive = true

    TaskGoStraightToCoord(npcPed, playerCoords.x, playerCoords.y, playerCoords.z, Config.NPC.walkSpeed, -1, 0.0, 0.0)

    Citizen.CreateThread(function()
        local interactionDone = false

        while npcActive and DoesEntityExist(npcPed) and not interactionDone do
            Citizen.Wait(100)

            local npcCoords = GetEntityCoords(npcPed)
            local playerCoords = GetEntityCoords(PlayerPedId())
            local distToPlayer = #(npcCoords - playerCoords)

            if distToPlayer <= Config.NPC.approachDistance then
                local chosenDrug = GetRandomEntry(unlockedDrugs)
                TriggerEvent('rd_drugdealer:startSale', npcPed, chosenDrug)
                interactionDone = true
            elseif distToPlayer > Config.NPC.despawnDistance then
                DeleteEntity(npcPed)
                npcActive = false
                interactionDone = true
            end
        end
    end)
end

RegisterNetEvent('rd_drugdealer:startSale')
AddEventHandler('rd_drugdealer:startSale', function(npc, drug)
    if not selling or not DoesEntityExist(npc) then return end

    npcActive = true
    local playerPed = PlayerPedId()
    local npcPed = npc

    -- Make NPC walk up to player within approachDistance
    local approachDistance = Config.NPC.approachDistance or 2.5
    TaskGoStraightToCoord(npcPed, GetEntityCoords(playerPed), 1.0, -1, 0.0, 0.0)
    
    -- Wait until NPC is close enough or timeout after 10 seconds
    local timeout = 10000
    local startTime = GetGameTimer()

    while npcActive do
        local dist = #(GetEntityCoords(npcPed) - GetEntityCoords(playerPed))
        if dist <= approachDistance then
            break
        end
        if GetGameTimer() - startTime > timeout then
            -- Timeout, break so NPC doesn’t walk forever
            break
        end
        Citizen.Wait(100)
    end

    -- Clear NPC tasks so it stops walking
    ClearPedTasks(npcPed)

    -- Both face each other
    TaskTurnPedToFaceEntity(playerPed, npcPed, 1000)
    TaskTurnPedToFaceEntity(npcPed, playerPed, 1000)
    Citizen.Wait(1000)

    -- Load animation dictionary
    local animDict = 'mp_common'
    RequestAnimDict(animDict)
    while not HasAnimDictLoaded(animDict) do Citizen.Wait(10) end

    -- Load props
    local drugPropModel = `ng_proc_drug01a002`
    local cashPropModel = `prop_cash_note_01`

    RequestModel(drugPropModel)
    RequestModel(cashPropModel)

    while not HasModelLoaded(drugPropModel) or not HasModelLoaded(cashPropModel) do
        Citizen.Wait(10)
    end

    -- Create and attach props
    local drugProp = CreateObject(drugPropModel, 0, 0, 0, true, true, false)
    local cashProp = CreateObject(cashPropModel, 0, 0, 0, true, true, false)

    AttachEntityToEntity(drugProp, playerPed, GetPedBoneIndex(playerPed, 57005), 0.15, 0.0, 0.0, 90.0, 180.0, 0.0, true, true, false, true, 1, true)
    AttachEntityToEntity(cashProp, npcPed, GetPedBoneIndex(npcPed, 57005), 0.15, 0.0, 0.0, 90.0, 180.0, 0.0, true, true, false, true, 1, true)

    -- Play the handoff animation
    TaskPlayAnim(playerPed, animDict, 'givetake1_a', 8.0, -8, 2000, 49, 0, false, false, false)
    TaskPlayAnim(npcPed, animDict, 'givetake1_a', 8.0, -8, 2000, 49, 0, false, false, false)

    Citizen.Wait(3500)

    -- Cleanup props
    DeleteEntity(drugProp)
    DeleteEntity(cashProp)

    TriggerServerEvent('rd_drugdealer:processSale', drug)

    npcActive = false
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        if selling and not npcActive then
            debugPrint("Attempting to spawn NPC...")
            local waitTime = math.random(Config.NPC.timeBetweenSpawns.min, Config.NPC.timeBetweenSpawns.max)
            SpawnBuyer()
            Citizen.Wait(waitTime)
        else
            Citizen.Wait(1000)
        end
    end
end)

RegisterNetEvent('rd_drugdealer:saleResult')
AddEventHandler('rd_drugdealer:saleResult', function(success, drug, xp, level, leveledUp)
    if not selling then return end

    if not success then
        lib.notify({
            title = Config.NotificationTitles.script,
            description = ("You don't have any %s to sell!"):format(drug.item),
            type = 'error'
        })
    else
        lib.notify({
            title = Config.NotificationTitles.script,
            description = ("Sold %s for $%d\n+%d XP"):format(drug.item, drug.price, xp),
            type = 'success'
        })

        if leveledUp then
            lib.notify({
                title = "Trap XP Notification",
                description = ("🎉 You've reached Level %d!"):format(level),
                type = 'inform'
            })
        end

        playerLevel = level or playerLevel
    end

    if DoesEntityExist(npcPed) then
        ClearPedTasks(npcPed)
        TaskWanderStandard(npcPed, 10.0, 10)
        SetPedAsNoLongerNeeded(npcPed)
    end

    ClearPedTasks(PlayerPedId())
    npcPed = nil
    npcActive = false
end)
