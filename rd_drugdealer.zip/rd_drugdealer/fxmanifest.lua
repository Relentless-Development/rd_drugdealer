fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Relentless Development'
description 'Advanced Npc Drug Sell Script '
version '1.0.0'

shared_script 'config.lua'

server_scripts {
    '@ox_lib/init.lua',  -- if you want to use ox_lib later, can remove if not needed now
    '@es_extended/locale.lua',
    'server/main.lua'
}

client_scripts {
    '@ox_lib/init.lua',  -- same as above
    '@es_extended/locale.lua',
    'client/main.lua'
}
