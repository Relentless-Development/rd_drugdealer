Config = {}

Config.Commands = {
    start = 'trap',
    stop = 'stoptrap'
}

Config.SellableDrugs = {
    {
        item = "weed_pooch",
        label = "Weed",
        price = 800,
        requiredLevel = 1,
        minAmount = 1,
        maxAmount = 15,
    },
    {
        item = "meth_pooch",
        label = "Meth",
        price = 1000,
        requiredLevel = 3,
        minAmount = 1,
        maxAmount = 15,
    },
    {
        item = "coke_pooch",
        label = "Coke",
        price = 1500,
        requiredLevel = 5,
        minAmount = 1,
        maxAmount = 15,
    },
    {
        item = "heroin_pooch",
        label = "Heroin",
        price = 2000,
        requiredLevel = 7,
        minAmount = 1,
        maxAmount = 15,
    }
}

Config.NotificationTitles = {
    script = 'Trap Notification',
    startSuccess = 'You Started Trapping.',
    stopSuccess = 'You stopped Trapping.'
}

Config.NotificationTypes = {
    start = 'success',
    stop = 'error'
}

Config.NPC = {
    models = { 'a_m_m_skater_01', 'a_f_m_bevhills_01', 'a_m_m_business_01' }, -- Ped models for buyers
    spawnRadius = 30.0, -- How far NPCs spawn from player
    approachDistance = 2.5, -- Distance NPC walks up to player to start interaction
    despawnDistance = 40.0, -- Distance from player before NPC despawns
    walkSpeed = 1.0, -- NPC walk speed
    timeBetweenSpawns = { min = 1500, max = 3000 } -- Min/max time between spawning NPCs in ms
}

Config.Levels = {
    [2] = 50,
    [3] = 150,
    [4] = 275,
    [5] = 325,
    [6] = 440,
    [7] = 575,
    [8] = 680,
    [9] = 795,
    [10] = 1500
}
