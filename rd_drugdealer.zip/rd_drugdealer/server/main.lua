ESX = exports['es_extended']:getSharedObject()

local SellingPlayers = {}
local PlayerXP = {}

-- Helper functions for XP
local function GetPlayerXP(source)
    if PlayerXP[source] then
        return PlayerXP[source].xp or 0
    else
        PlayerXP[source] = { xp = 0, level = 1 }
        return 0
    end
end

local function GetLevelFromXP(xp)
    for level, xpNeeded in pairs(Config.Levels) do
        if xp < xpNeeded then
            return level - 1
        end
    end
    return #Config.Levels
end

-- Trap command (toggle selling mode)
RegisterCommand(Config.Commands.start, function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    if not SellingPlayers[source] then
        SellingPlayers[source] = true
        TriggerClientEvent('rd_drugdealer:notifyToggle', source, true)
    else
        SellingPlayers[source] = nil
        TriggerClientEvent('rd_drugdealer:notifyToggle', source, false)
    end
end, false)

-- Stop command
RegisterCommand(Config.Commands.stop, function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    if SellingPlayers[source] then
        SellingPlayers[source] = nil
        TriggerClientEvent('rd_drugdealer:notifyToggle', source, false)
    end
end, false)

-- Process Sale event
RegisterNetEvent('rd_drugdealer:processSale')
AddEventHandler('rd_drugdealer:processSale', function(drug)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer or type(drug) ~= "table" or not drug.item then return end

    local hasItem = xPlayer.getInventoryItem(drug.item)
    if hasItem.count < 1 then
        TriggerClientEvent('rd_drugdealer:saleResult', src, false, drug)
        return
    end

    xPlayer.removeInventoryItem(drug.item, 1)
    xPlayer.addAccountMoney('black_money', drug.price)

    -- XP logic
    if not PlayerXP[src] then
        PlayerXP[src] = { xp = 0, level = 1 }
    end

    local xpGain = math.random(5, 13)
    PlayerXP[src].xp = PlayerXP[src].xp + xpGain

    local leveledUp = false
    local nextLevel = PlayerXP[src].level + 1
    local levelXP = Config.Levels[nextLevel]
    if levelXP and PlayerXP[src].xp >= levelXP then
        PlayerXP[src].level = nextLevel
        leveledUp = true
    end

    -- Save to database
    local identifier = xPlayer.getIdentifier()
    exports.oxmysql:update('UPDATE users SET trap_xp = ?, trap_level = ? WHERE identifier = ?', {
        PlayerXP[src].xp,
        PlayerXP[src].level,
        identifier
    })

    -- Notify client
    TriggerClientEvent('rd_drugdealer:saleResult', src, true, drug, xpGain, PlayerXP[src].level, leveledUp)
end)
-- Optional XP command
ESX.RegisterCommand('xp', {'user'}, function(xPlayer)
    local src = xPlayer.source
    if not PlayerXP[src] then
        PlayerXP[src] = { xp = 0, level = 1 }
    end
    local info = PlayerXP[src]
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Drug XP',
        description = ('Level %d | XP: %d'):format(info.level, info.xp),
        type = 'inform'
    })
end, false)

ESX.RegisterServerCallback('rd_drugdealer:getPlayerLevel', function(source, cb)
    local xp = GetPlayerXP(source)
    local level = GetLevelFromXP(xp)
    cb(level)
end)

AddEventHandler('esx:playerLoaded', function(source, xPlayer)
    local identifier = xPlayer.getIdentifier()

    exports.oxmysql:execute('SELECT trap_xp, trap_level FROM users WHERE identifier = ?', { identifier }, function(result)
        if result and result[1] then
            PlayerXP[source] = {
                xp = tonumber(result[1].trap_xp) or 0,
                level = tonumber(result[1].trap_level) or 1
            }
        else
            PlayerXP[source] = { xp = 0, level = 1 }
        end
    end)
end)